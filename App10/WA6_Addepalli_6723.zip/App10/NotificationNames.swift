//
//  NotificationNames.swift
//  App10
//
//  Created by Srinivasa Sameer Addepalli on 10/23/24.
//

import Foundation
extension Notification.Name{
    static let edit = Notification.Name("edit")
    static let delete = Notification.Name("delete")
}
