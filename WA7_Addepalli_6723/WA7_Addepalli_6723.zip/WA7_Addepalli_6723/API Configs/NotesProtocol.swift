//
//  NotesProtocol.swift
//  WA7_Addepalli_6723
//
//  Created by Srinivasa Sameer Addepalli on 11/3/24.
//

import Foundation

protocol NotesProtocol {
    func getNotes()
    func addANewNote(note: Note)
}
