//
//  APIConfigs.swift
//  App10
//
//  Created by Srinivasa Sameer Addepalli on 10/22/24.
//

import Foundation

class APIConfigs {
    static let baseURL = "http://apis.sakibnm.work:8888/contacts/text/"
}
