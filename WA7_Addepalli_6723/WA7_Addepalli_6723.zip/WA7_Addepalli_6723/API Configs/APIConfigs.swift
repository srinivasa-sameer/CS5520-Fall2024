//
//  APIConfigs.swift
//  WA7_Addepalli_6723
//
//  Created by Srinivasa Sameer Addepalli on 11/3/24.
//

import Foundation

class APIConfigs {
    //MARK: API base URL...
    static let baseURL = "http://apis.sakibnm.work:3000/api/"
}
