//
//  Utilities.swift
//  WA4_Addepalli_6723
//
//  Created by Srinivasa Sameer Addepalli on 10/6/24.
//

import Foundation

class Utilities{
    static let phoneTypes:[String] = ["Cell", "Work", "Home"]
}
